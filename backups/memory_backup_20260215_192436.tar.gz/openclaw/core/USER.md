# USER.md - User Profile

- Name: Artale
- Preferred address: Artale
- Pronouns (optional):
- Timezone (optional):
- Notes:
